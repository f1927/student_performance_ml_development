from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

model = pickle.load(open("student_model.pkl", "rb"))

@app.route("/", methods=["GET", "POST"])
def index():
    prediction = ""
    if request.method == "POST":
        age = float(request.form["age"])
        study_hours = float(request.form["study_hours"])
        attendance = float(request.form["attendance"])
        prev_score = float(request.form["prev_score"])
        internet_hours = float(request.form["internet_hours"])

        data = np.array([[age, study_hours, attendance, prev_score, internet_hours]])
        result = model.predict(data)[0]

        prediction = "PASS ✅" if result == 1 else "FAIL ❌"

    return render_template("index.html", prediction=prediction)

if __name__ == "__main__":
    app.run(debug=True)
